"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { LocationSelector } from "@/components/location-selector"

export default function Home() {
  const router = useRouter()
  const [selectedArea, setSelectedArea] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")

  const handleSearch = () => {
    const searchParams = new URLSearchParams()
    if (selectedArea) searchParams.append("area", selectedArea)
    if (selectedSubject) searchParams.append("subject", selectedSubject)
    router.push(`/search?${searchParams.toString()}`)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-blue-600 text-xl font-semibold">
              Home Tutor Finder
            </Link>
            <nav className="hidden md:flex items-center space-x-1">
              <Button asChild variant="navActive">
                <Link href="/">Home</Link>
              </Button>
              <Button asChild variant="nav">
                <Link href="/view-post">View Post</Link>
              </Button>
              <Button asChild variant="nav">
                <Link href="/add-to-list">Add to List</Link>
              </Button>
              <Button asChild variant="nav">
                <Link href="/ideal-teacher">Ideal Teacher</Link>
              </Button>
              <Button asChild variant="nav">
                <Link href="/my-account">My Account</Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-2xl md:text-3xl font-bold text-center mb-8">Find Your Perfect Home Tutor in Bangladesh</h1>

        <div className="max-w-3xl mx-auto">
          <LocationSelector onAreaChange={setSelectedArea} onSubjectChange={setSelectedSubject} />

          <Button className="w-full bg-black text-white hover:bg-gray-800 mb-6" onClick={handleSearch}>
            Search Tutors
          </Button>

          <div className="text-center">
            <Button variant="outline">Post as Tutor</Button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white mt-auto py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center items-center gap-4 text-sm text-gray-600">
            <Link href="/privacy-policy" className="hover:text-gray-900">
              Privacy Policy
            </Link>
            <Link href="/disclaimer" className="hover:text-gray-900">
              Disclaimer
            </Link>
            <Link href="/about-us" className="hover:text-gray-900">
              About Us
            </Link>
            <Link href="/contact-us" className="hover:text-gray-900">
              Contact Us
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

