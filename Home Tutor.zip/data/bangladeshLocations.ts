export const bangladeshLocations = {
  Dhaka: {
    districts: {
      Dhaka: ["Uttara", "Mirpur", "Dhanmondi", "Gulshan", "Banani", "Mohammadpur"],
      Gazipur: ["Gazipur Sadar", "Tongi", "Kashimpur"],
      Narayanganj: ["Narayanganj Sadar", "Fatulla", "Siddhirganj"],
    },
  },
  Chittagong: {
    districts: {
      Chittagong: ["Agrabad", "GEC Circle", "Nasirabad", "Halishahar"],
      "Cox's Bazar": ["Cox's Bazar Sadar", "Teknaf", "Ukhia"],
    },
  },
  // Add more divisions and districts as needed
}

export const subjectOptions = [
  "Mathematics",
  "English",
  "Physics",
  "Chemistry",
  "Biology",
  "Bangla",
  "ICT",
  "Accounting",
]

