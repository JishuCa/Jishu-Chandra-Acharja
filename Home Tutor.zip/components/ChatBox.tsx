"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Send } from "lucide-react"

interface Message {
  sender: "user" | "tutor"
  content: string
  timestamp: Date
}

interface ChatBoxProps {
  isOpen: boolean
  onClose: () => void
  tutorName: string
}

export function ChatBox({ isOpen, onClose, tutorName }: ChatBoxProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [scrollToBottom])

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const userMessage: Message = {
        sender: "user",
        content: newMessage,
        timestamp: new Date(),
      }
      setMessages((prevMessages) => [...prevMessages, userMessage])

      // Simulate tutor response
      setTimeout(() => {
        const tutorMessage: Message = {
          sender: "tutor",
          content: `Thank you for your message. This is an automated response from ${tutorName}.`,
          timestamp: new Date(),
        }
        setMessages((prevMessages) => [...prevMessages, tutorMessage])
      }, 1000)

      setNewMessage("")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Chat with {tutorName}</DialogTitle>
          <DialogDescription>Send messages to communicate with your tutor or student.</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[300px] p-4 border rounded">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`mb-2 p-2 rounded ${
                message.sender === "user" ? "bg-blue-100 ml-auto" : "bg-gray-100"
              } max-w-[80%]`}
            >
              <p className="text-sm">{message.content}</p>
              <p className="text-xs text-gray-500 mt-1">{message.timestamp.toLocaleTimeString()}</p>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </ScrollArea>
        <div className="flex items-center mt-4">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow"
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                handleSendMessage()
              }
            }}
          />
          <Button onClick={handleSendMessage} className="ml-2">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

