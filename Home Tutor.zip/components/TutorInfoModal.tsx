import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface TutorInfo {
  name: string
  subject: string
  occupation: string
  experience: number
  education: string
  address: string
  salary: number
  briefIntroduction: string
  email?: string
  phoneNumber: string
  dateOfBirth: string
  gender: string
  educationLevel: string
  institution: string
  subjects?: string[]
  division: string
  district: string
  area: string
  availableDays?: string[]
  availableTimes: string
  preferredTeachingMethod: string
}

interface TutorInfoModalProps {
  isOpen: boolean
  onClose: () => void
  tutorInfo: TutorInfo
}

export function TutorInfoModal({ isOpen, onClose, tutorInfo }: TutorInfoModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{tutorInfo.name}</DialogTitle>
          <DialogDescription>Tutor Information</DialogDescription>
        </DialogHeader>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold text-lg mb-2">Personal Information</h3>
            {tutorInfo.email && (
              <p>
                <strong>Email:</strong> {tutorInfo.email}
              </p>
            )}
            <p>
              <strong>Phone:</strong> {tutorInfo.phoneNumber}
            </p>
            <p>
              <strong>Date of Birth:</strong> {tutorInfo.dateOfBirth}
            </p>
            <p>
              <strong>Gender:</strong> {tutorInfo.gender}
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Educational Background</h3>
            <p>
              <strong>Education Level:</strong> {tutorInfo.educationLevel}
            </p>
            <p>
              <strong>Institution:</strong> {tutorInfo.institution}
            </p>
            {tutorInfo.subjects && (
              <p>
                <strong>Subjects:</strong> {tutorInfo.subjects.join(", ")}
              </p>
            )}
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Teaching Information</h3>
            <p>
              <strong>Subject:</strong> {tutorInfo.subject}
            </p>
            <p>
              <strong>Occupation:</strong> {tutorInfo.occupation}
            </p>
            <p>
              <strong>Experience:</strong> {tutorInfo.experience} years
            </p>
            <p>
              <strong>Preferred Teaching Method:</strong> {tutorInfo.preferredTeachingMethod}
            </p>
            <p>
              <strong>Salary:</strong> {tutorInfo.salary} BDT/month
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Location</h3>
            <p>
              <strong>Address:</strong> {tutorInfo.address}
            </p>
          </div>
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-2">Availability</h3>
            {tutorInfo.availableDays && (
              <p>
                <strong>Available Days:</strong> {tutorInfo.availableDays.join(", ")}
              </p>
            )}
            <p>
              <strong>Available Times:</strong> {tutorInfo.availableTimes}
            </p>
          </div>
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-2">Brief Introduction</h3>
            <p>{tutorInfo.briefIntroduction}</p>
          </div>
        </div>
        <div className="mt-6 flex justify-end">
          <Button onClick={onClose}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

