"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"
import { ChatBox } from "@/components/ChatBox"

export function SMSButton() {
  const [isChatOpen, setIsChatOpen] = useState(false)

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 rounded-full w-12 h-12 shadow-lg bg-blue-600 hover:bg-blue-700"
        onClick={() => setIsChatOpen(true)}
      >
        <MessageCircle className="w-6 h-6" />
      </Button>
      <ChatBox isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} tutorName="Support" />
    </>
  )
}

