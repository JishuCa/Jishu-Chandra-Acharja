import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

interface FilterModalProps {
  isOpen: boolean
  onClose: () => void
  onApplyFilters: (filters: FilterOptions) => void
}

export interface FilterOptions {
  occupation: string
  minExperience: number
  gender: string
  educationLevel: string
  minSalary: number
  maxSalary: number
}

export function FilterModal({ isOpen, onClose, onApplyFilters }: FilterModalProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    occupation: "",
    minExperience: 0,
    gender: "",
    educationLevel: "",
    minSalary: 0,
    maxSalary: 50000,
  })

  const handleChange = (name: keyof FilterOptions, value: string | number) => {
    setFilters((prev) => ({ ...prev, [name]: value }))
  }

  const handleApplyFilters = () => {
    onApplyFilters(filters)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Filter Tutors</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="occupation" className="text-right">
              Occupation
            </Label>
            <Select value={filters.occupation} onValueChange={(value) => handleChange("occupation", value)}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select occupation" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                <SelectItem value="student">Student</SelectItem>
                <SelectItem value="ex-student">Ex-Student</SelectItem>
                <SelectItem value="teacher">Teacher</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="minExperience" className="text-right">
              Min Experience
            </Label>
            <Input
              id="minExperience"
              type="number"
              value={filters.minExperience}
              onChange={(e) => handleChange("minExperience", Number.parseInt(e.target.value))}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="gender" className="text-right">
              Gender
            </Label>
            <Select value={filters.gender} onValueChange={(value) => handleChange("gender", value)}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="educationLevel" className="text-right">
              Education
            </Label>
            <Select value={filters.educationLevel} onValueChange={(value) => handleChange("educationLevel", value)}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select education level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                <SelectItem value="ssc">SSC</SelectItem>
                <SelectItem value="hsc">HSC</SelectItem>
                <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                <SelectItem value="masters">Master's Degree</SelectItem>
                <SelectItem value="phd">PhD</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Salary Range</Label>
            <div className="col-span-3 space-y-2">
              <Slider
                min={0}
                max={50000}
                step={1000}
                value={[filters.minSalary, filters.maxSalary]}
                onValueChange={([min, max]) => {
                  handleChange("minSalary", min)
                  handleChange("maxSalary", max)
                }}
              />
              <div className="flex justify-between text-sm">
                <span>{filters.minSalary} BDT</span>
                <span>{filters.maxSalary} BDT</span>
              </div>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleApplyFilters}>
            Apply Filters
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

