"use client"

import { useState, useEffect } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { locationData, type Division, type District, type Area } from "@/lib/location-data"

interface LocationSelectorProps {
  onAreaChange: (area: string) => void
  onSubjectChange: (subject: string) => void
}

const subjects = [
  "Mathematics",
  "English",
  "Physics",
  "Chemistry",
  "Biology",
  "Bangla",
  "ICT",
  "Accounting",
  "History",
  "Geography",
  "Economics",
  "Business Studies",
  "Statistics",
  "Political Science",
  "Sociology",
  "Psychology",
  "Islamic Studies",
  "Computer Science",
  "Art",
  "Music",
]

export function LocationSelector({ onAreaChange, onSubjectChange }: LocationSelectorProps) {
  const [selectedDivision, setSelectedDivision] = useState<Division | null>(null)
  const [selectedDistrict, setSelectedDistrict] = useState<District | null>(null)
  const [selectedArea, setSelectedArea] = useState<Area | null>(null)

  const divisions = Object.keys(locationData) as Division[]
  const districts = selectedDivision ? (Object.keys(locationData[selectedDivision].districts) as District[]) : []
  const areas = selectedDistrict && selectedDivision ? locationData[selectedDivision].districts[selectedDistrict] : []

  useEffect(() => {
    if (selectedArea) {
      onAreaChange(selectedArea)
    }
  }, [selectedArea, onAreaChange])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
      <Select
        onValueChange={(value) => {
          setSelectedDivision(value as Division)
          setSelectedDistrict(null)
          setSelectedArea(null)
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Division" />
        </SelectTrigger>
        <SelectContent>
          {divisions.map((division) => (
            <SelectItem key={division} value={division}>
              {division}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        disabled={!selectedDivision}
        onValueChange={(value) => {
          setSelectedDistrict(value as District)
          setSelectedArea(null)
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select District" />
        </SelectTrigger>
        <SelectContent>
          {districts.map((district) => (
            <SelectItem key={district} value={district}>
              {district}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        disabled={!selectedDistrict}
        onValueChange={(value) => {
          setSelectedArea(value as Area)
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Area" />
        </SelectTrigger>
        <SelectContent>
          {areas.map((area) => (
            <SelectItem key={area} value={area}>
              {area}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select onValueChange={onSubjectChange}>
        <SelectTrigger>
          <SelectValue placeholder="Select Subject" />
        </SelectTrigger>
        <SelectContent>
          {subjects.map((subject) => (
            <SelectItem key={subject} value={subject}>
              {subject}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

