"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function BackButton() {
  return (
    <Link href="/">
      <Button variant="outline" className="mb-6">
        Back
      </Button>
    </Link>
  )
}

