"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { TutorInfoModal } from "@/components/TutorInfoModal"
import { useToast } from "@/components/ui/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface TutorCardProps {
  id: number
  name: string
  subject: string
  occupation: string
  experience: number
  education: string
  address: string
  salary: number
  imageUrl: string
  briefIntroduction: string
  dateOfBirth: string
  gender: string
  educationLevel: string
  institution: string
  subjects?: string[]
  division: string
  district: string
  area: string
  availableDays?: string[]
  availableTimes: string
  preferredTeachingMethod: string
  onAddToList: (tutorId: number) => void
  isUserSignedIn: boolean
}

export function TutorCard(props: TutorCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isImageModalOpen, setIsImageModalOpen] = useState(false)
  const { toast } = useToast()

  const openModal = () => setIsModalOpen(true)
  const closeModal = () => setIsModalOpen(false)

  const handleAddToList = () => {
    props.onAddToList(props.id)
  }

  const showSignInMessage = () => {
    toast({
      title: "Sign in required",
      description: "Please sign in to access this feature.",
      duration: 3000,
    })
  }

  const handleMessageClick = () => {
    if (props.isUserSignedIn) {
      // Implement messaging functionality here
      console.log("Open messaging for tutor:", props.id)
    } else {
      showSignInMessage()
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md flex">
      <div className="flex flex-col items-center mr-6 w-32">
        <Image
          src={props.imageUrl || "/placeholder.svg"}
          alt={props.name}
          width={100}
          height={100}
          className="rounded-full mb-4"
        />
        <Button variant="secondary" size="sm" onClick={() => setIsImageModalOpen(true)} className="w-full mb-2">
          View Photo
        </Button>
        <Button variant="outline" size="sm" onClick={handleAddToList} className="w-full">
          Add to List
        </Button>
      </div>
      <div className="flex-grow">
        <h2 className="text-xl font-semibold mb-2">{props.name}</h2>
        <p className="mb-1">
          <span className="font-medium">Subject:</span> {props.subject}
        </p>
        <p className="mb-1">
          <span className="font-medium">Occupation:</span> {props.occupation}
        </p>
        <p className="mb-1">
          <span className="font-medium">Experience:</span> {props.experience} years
        </p>
        <p className="mb-1">
          <span className="font-medium">Education:</span> {props.education}
        </p>
        <p className="mb-1">
          <span className="font-medium">Salary:</span> {props.salary} BDT/month
        </p>
        <p className="mb-4">
          <span className="font-medium">Address:</span> {props.address}
        </p>
        <div className="flex justify-end space-x-2">
          <Button variant="outline" size="sm" onClick={handleMessageClick}>
            Message
          </Button>
          <Button variant="secondary" size="sm" onClick={openModal}>
            View Bio
          </Button>
        </div>
      </div>
      <TutorInfoModal isOpen={isModalOpen} onClose={closeModal} tutorInfo={props} />
      <Dialog open={isImageModalOpen} onOpenChange={setIsImageModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{props.name}</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center">
            <Image
              src={props.imageUrl || "/placeholder.svg"}
              alt={props.name}
              width={300}
              height={300}
              className="rounded-lg"
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

