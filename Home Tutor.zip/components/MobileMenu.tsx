"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export function MobileMenu() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  return (
    <>
      <Button variant="ghost" className="md:hidden text-white" onClick={toggleMobileMenu}>
        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </Button>
      {isMobileMenuOpen && (
        <nav className="md:hidden bg-blue-700 py-2 absolute top-16 left-0 right-0 z-50">
          <div className="container mx-auto px-4 flex flex-col space-y-2">
            <Link href="/" className="text-white hover:bg-blue-600 py-2 px-4 rounded">
              Home
            </Link>
            <Link href="/search" className="text-white hover:bg-blue-600 py-2 px-4 rounded">
              View Post
            </Link>
            <Link href="/add-to-list" className="text-white hover:bg-blue-600 py-2 px-4 rounded">
              Add to List
            </Link>
            <Link href="/teaching-tricks" className="text-white hover:bg-blue-600 py-2 px-4 rounded">
              Teaching Tricks
            </Link>
            <Link href="/my-account" className="text-white hover:bg-blue-600 py-2 px-4 rounded">
              My Account
            </Link>
          </div>
        </nav>
      )}
    </>
  )
}

