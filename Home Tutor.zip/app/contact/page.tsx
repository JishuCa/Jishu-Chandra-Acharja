"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function ContactPage() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [subject, setSubject] = useState("")
  const [message, setMessage] = useState("")
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Here you would typically send the form data to your backend
    // For now, we'll just show a success message
    console.log("Form submitted:", { name, email, subject, message })

    toast({
      title: "Message Sent",
      description: "Your message has been sent successfully!",
    })

    // Clear the form
    setName("")
    setEmail("")
    setSubject("")
    setMessage("")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Contact Us</h1>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
        <div>
          <label htmlFor="name" className="block mb-1">
            Name:
          </label>
          <Input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="email" className="block mb-1">
            Email:
          </label>
          <Input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="subject" className="block mb-1">
            Subject:
          </label>
          <Input type="text" id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="message" className="block mb-1">
            Message:
          </label>
          <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} required rows={4} />
        </div>
        <Button type="submit">Send Message</Button>
      </form>
    </div>
  )
}

