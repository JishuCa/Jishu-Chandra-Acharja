"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { LocationSelector } from "@/components/location-selector"
import { Button } from "@/components/ui/button"

export default function HomeClient() {
  const router = useRouter()
  const [selectedArea, setSelectedArea] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")

  const handleSearch = () => {
    const searchParams = new URLSearchParams()
    if (selectedArea) searchParams.append("area", selectedArea)
    if (selectedSubject) searchParams.append("subject", selectedSubject)
    router.push(`/search?${searchParams.toString()}`)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-2xl md:text-3xl font-bold text-center mb-8">Find Your Perfect Home Tutor in Bangladesh</h1>

        <div className="max-w-3xl mx-auto">
          <LocationSelector onAreaChange={setSelectedArea} onSubjectChange={setSelectedSubject} />

          <Button className="w-full bg-black text-white hover:bg-gray-800 mb-6" onClick={handleSearch}>
            Search Tutors
          </Button>

          <div className="text-center space-y-4">
            <Link href="/post-tutor">
              <Button variant="outline" className="w-full">
                Post as Tutor
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button variant="outline" className="w-full">
                Sign In
              </Button>
            </Link>
            <Link href="/sign-up">
              <Button variant="outline" className="w-full">
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}

