import HomeClient from "./HomeClient"

export const metadata = {
  title: "Home Tutor Finder",
  description: "Find your perfect home tutor in Bangladesh",
}

export default function Home() {
  return <HomeClient />
}

