"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { locationData, type Division, type District } from "@/lib/location-data"
import BackButton from "@/components/BackButton"

export default function PostTutor() {
  const router = useRouter()

  const [formData, setFormData] = useState({
    fullName: "",
    phoneNumber: "",
    isPhoneVerified: false,
    dateOfBirth: "",
    gender: "",
    occupation: "",
    educationLevel: "",
    institution: "",
    subjects: [] as string[],
    teachingExperience: "",
    division: "",
    district: "",
    area: "",
    address: "",
    availableDays: [] as string[],
    availableTimes: "",
    preferredTeachingMethod: "",
    expectedSalary: "",
    briefIntroduction: "",
    profilePhoto: null as File | null,
  })

  const [districts, setDistricts] = useState<string[]>([])
  const [areas, setAreas] = useState<string[]>([])
  const [verificationCode, setVerificationCode] = useState("")
  const [showVerificationInput, setShowVerificationInput] = useState(false)
  const [error, setError] = useState("")

  const divisions = Object.keys(locationData) as Division[]

  useEffect(() => {
    if (formData.division && locationData[formData.division as Division]) {
      setDistricts(Object.keys(locationData[formData.division as Division].districts))
    } else {
      setDistricts([])
    }
    setFormData((prev) => ({ ...prev, district: "", area: "" }))
  }, [formData.division])

  useEffect(() => {
    if (
      formData.division &&
      formData.district &&
      locationData[formData.division as Division] &&
      locationData[formData.division as Division].districts[formData.district as District]
    ) {
      setAreas(locationData[formData.division as Division].districts[formData.district as District])
    } else {
      setAreas([])
    }
    setFormData((prev) => ({ ...prev, area: "" }))
  }, [formData.division, formData.district])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleMultiSelect = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: prev[name].includes(value) ? prev[name].filter((item: string) => item !== value) : [...prev[name], value],
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      if (file.size > 100 * 1024) {
        setError("File size must be less than 100 KB")
        return
      }
      setFormData((prev) => ({ ...prev, profilePhoto: file }))
    }
  }

  const handleVerifyPhone = () => {
    console.log("Sending verification code to", formData.phoneNumber)
    setShowVerificationInput(true)
  }

  const handleVerificationSubmit = () => {
    console.log("Verifying code", verificationCode)
    setFormData((prev) => ({ ...prev, isPhoneVerified: true }))
    setShowVerificationInput(false)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Submitting tutor data:", formData)
    router.push("/tutor-posted")
  }

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <BackButton />
        <Card>
          <CardHeader>
            <CardTitle>Post as Tutor</CardTitle>
            <CardDescription>Fill in your details to create your tutor profile</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="fullName">Full Name*</Label>
                  <Input id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
                </div>

                <div>
                  <Label htmlFor="phoneNumber">Phone Number*</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="phoneNumber"
                      name="phoneNumber"
                      value={formData.phoneNumber}
                      onChange={handleChange}
                      required
                    />
                    <Button type="button" onClick={handleVerifyPhone} disabled={formData.isPhoneVerified}>
                      {formData.isPhoneVerified ? "Verified" : "Verify"}
                    </Button>
                  </div>
                </div>

                {showVerificationInput && (
                  <div>
                    <Label htmlFor="verificationCode">Verification Code</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="verificationCode"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value)}
                      />
                      <Button type="button" onClick={handleVerificationSubmit}>
                        Submit
                      </Button>
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth*</Label>
                  <Input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="gender">Gender*</Label>
                  <Select onValueChange={handleSelectChange("gender")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="occupation">Occupation*</Label>
                  <Select onValueChange={handleSelectChange("occupation")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Occupation" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="ex-student">Ex-Student</SelectItem>
                      <SelectItem value="teacher">Teacher</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="educationLevel">Education Level*</Label>
                  <Select onValueChange={handleSelectChange("educationLevel")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Education Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ssc">SSC</SelectItem>
                      <SelectItem value="hsc">HSC</SelectItem>
                      <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                      <SelectItem value="masters">Master's Degree</SelectItem>
                      <SelectItem value="phd">PhD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="institution">Institution*</Label>
                  <Input
                    id="institution"
                    name="institution"
                    value={formData.institution}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <Label>Subjects*</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      "Mathematics",
                      "English",
                      "Physics",
                      "Chemistry",
                      "Biology",
                      "Bangla",
                      "ICT",
                      "Accounting",
                      "History",
                      "Geography",
                      "Economics",
                      "Business Studies",
                      "Statistics",
                      "Political Science",
                      "Sociology",
                      "Psychology",
                      "Islamic Studies",
                      "Computer Science",
                      "Art",
                      "Music",
                    ].map((subject) => (
                      <div key={subject} className="flex items-center">
                        <Checkbox
                          id={`subject-${subject}`}
                          checked={formData.subjects.includes(subject)}
                          onCheckedChange={() => handleMultiSelect("subjects", subject)}
                        />
                        <label htmlFor={`subject-${subject}`} className="ml-2 text-sm text-gray-700">
                          {subject}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="teachingExperience">Teaching Experience (in years)*</Label>
                  <Input
                    id="teachingExperience"
                    name="teachingExperience"
                    type="number"
                    value={formData.teachingExperience}
                    onChange={handleChange}
                    required
                    min="0"
                  />
                </div>

                <div>
                  <Label htmlFor="division">Division*</Label>
                  <Select onValueChange={handleSelectChange("division")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Division" />
                    </SelectTrigger>
                    <SelectContent>
                      {divisions.map((division) => (
                        <SelectItem key={division} value={division}>
                          {division}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="district">District*</Label>
                  <Select onValueChange={handleSelectChange("district")} disabled={!formData.division}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select District" />
                    </SelectTrigger>
                    <SelectContent>
                      {districts.map((district) => (
                        <SelectItem key={district} value={district}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="area">Area*</Label>
                  <Select onValueChange={handleSelectChange("area")} disabled={!formData.district}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Area" />
                    </SelectTrigger>
                    <SelectContent>
                      {areas.map((area) => (
                        <SelectItem key={area} value={area}>
                          {area}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="address">Address*</Label>
                  <Textarea
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                    placeholder="Enter your full address"
                  />
                </div>

                <div>
                  <Label>Available Days*</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                      <div key={day} className="flex items-center">
                        <Checkbox
                          id={`day-${day}`}
                          checked={formData.availableDays.includes(day)}
                          onCheckedChange={() => handleMultiSelect("availableDays", day)}
                        />
                        <label htmlFor={`day-${day}`} className="ml-2 text-sm text-gray-700">
                          {day}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="availableTimes">Available Times*</Label>
                  <Input
                    id="availableTimes"
                    name="availableTimes"
                    value={formData.availableTimes}
                    onChange={handleChange}
                    required
                    placeholder="e.g., 08:00 AM - 09:00 AM, 02:00 PM - 03:00 PM"
                  />
                </div>

                <div>
                  <Label htmlFor="preferredTeachingMethod">Preferred Teaching Method*</Label>
                  <Select onValueChange={handleSelectChange("preferredTeachingMethod")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Teaching Method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="in_person">In-person</SelectItem>
                      <SelectItem value="online">Online</SelectItem>
                      <SelectItem value="both">Both In-person and Online</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="expectedSalary">Expected Salary (BDT per month)*</Label>
                  <Input
                    id="expectedSalary"
                    name="expectedSalary"
                    type="number"
                    value={formData.expectedSalary}
                    onChange={handleChange}
                    required
                    min="0"
                  />
                </div>

                <div>
                  <Label htmlFor="briefIntroduction">Brief Introduction*</Label>
                  <Textarea
                    id="briefIntroduction"
                    name="briefIntroduction"
                    value={formData.briefIntroduction}
                    onChange={handleChange}
                    required
                    className="h-32"
                    placeholder="Write a brief introduction about yourself, your teaching style, and why students should choose you as their tutor."
                  />
                </div>

                <div>
                  <Label htmlFor="profilePhoto">Profile Photo (Max 100 KB)*</Label>
                  <Input
                    id="profilePhoto"
                    name="profilePhoto"
                    type="file"
                    onChange={handleFileChange}
                    accept="image/*"
                    required
                  />
                </div>

                {error && <p className="text-red-500 text-sm">{error}</p>}

                <div className="flex justify-between">
                  <Button type="button" variant="outline" onClick={() => router.push("/")}>
                    Cancel
                  </Button>
                  <Button type="submit">Submit Tutor Profile</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

