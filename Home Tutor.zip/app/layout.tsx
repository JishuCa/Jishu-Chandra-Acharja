import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import Link from "next/link"
import { Toaster } from "@/components/ui/toaster"
import { Button } from "@/components/ui/button"
import { SMSButton } from "@/components/SMSButton"
import { MobileMenu } from "@/components/MobileMenu"
import type { Metadata } from "next"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Home Tutor Finder",
  description: "Find your perfect home tutor in Bangladesh",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-md">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              <Link href="/" className="text-2xl font-bold">
                Home Tutor Finder
              </Link>
              <nav className="hidden md:flex items-center space-x-1">
                <Button
                  asChild
                  variant="ghost"
                  className="text-white hover:bg-black hover:text-white transition-colors"
                >
                  <Link href="/">Home</Link>
                </Button>
                <Button
                  asChild
                  variant="ghost"
                  className="text-white hover:bg-black hover:text-white transition-colors"
                >
                  <Link href="/search">View Post</Link>
                </Button>
                <Button
                  asChild
                  variant="ghost"
                  className="text-white hover:bg-black hover:text-white transition-colors"
                >
                  <Link href="/add-to-list">Add to List</Link>
                </Button>
                <Button
                  asChild
                  variant="ghost"
                  className="text-white hover:bg-black hover:text-white transition-colors"
                >
                  <Link href="/teaching-tricks">Teaching Tricks</Link>
                </Button>
                <Button
                  asChild
                  variant="ghost"
                  className="text-white hover:bg-black hover:text-white transition-colors"
                >
                  <Link href="/my-account">My Account</Link>
                </Button>
              </nav>
              <MobileMenu />
            </div>
          </div>
        </header>
        <main>{children}</main>
        <footer className="border-t bg-white mt-auto py-4">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center items-center gap-4 text-sm text-gray-600">
              <Link href="/privacy-policy" className="hover:text-gray-900">
                Privacy Policy
              </Link>
              <Link href="/disclaimer" className="hover:text-gray-900">
                Disclaimer
              </Link>
              <Link href="/about-us" className="hover:text-gray-900">
                About Us
              </Link>
              <Link href="/contact-us" className="hover:text-gray-900">
                Contact Us
              </Link>
            </div>
          </div>
        </footer>
        <SMSButton />
        <Toaster />
      </body>
    </html>
  )
}



import './globals.css'