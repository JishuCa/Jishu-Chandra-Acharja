import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Home Tutor Finder",
  description: "Find your perfect home tutor in Bangladesh",
  generator: "v0.dev",
}

