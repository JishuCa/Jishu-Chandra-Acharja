"use client"

import { useState, useCallback, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { TutorCard } from "@/components/tutor-card"
import { Button } from "@/components/ui/button"
import { Filter } from "lucide-react"
import { FilterModal, type FilterOptions } from "@/components/FilterModal"
import { useToast } from "@/components/ui/use-toast"
import { Input } from "@/components/ui/input"

// Updated mock data for tutors with full address information and adjusted occupation/education
const mockTutors = [
  {
    id: 1,
    name: "John Doe",
    subject: "Mathematics",
    occupation: "Teacher",
    experience: 5,
    education: "Master's Degree in Mathematics",
    address: "123 Main St, Uttara, Dhaka 1230, Bangladesh",
    salary: 10000,
    imageUrl: "/placeholder.svg",
    briefIntroduction:
      "I'm a passionate math teacher with 5 years of experience. I specialize in making complex mathematical concepts easy to understand for students of all levels.",
    phoneNumber: "+880 1234567890",
    dateOfBirth: "1990-05-15",
    gender: "Male",
    educationLevel: "masters",
    institution: "University of Dhaka",
    subjects: ["Mathematics", "Physics"],
    division: "Dhaka",
    district: "Dhaka",
    area: "Uttara",
    availableDays: ["Monday", "Wednesday", "Friday"],
    availableTimes: "4:00 PM - 8:00 PM",
    preferredTeachingMethod: "In-person",
  },
  {
    id: 2,
    name: "Jane Smith",
    subject: "English",
    occupation: "Student",
    experience: 3,
    education: "Bachelor's Degree in English Literature",
    address: "456 Park Road, GEC Circle, Chittagong 4000, Bangladesh",
    salary: 8000,
    imageUrl: "/placeholder.svg",
    briefIntroduction:
      "As a recent graduate in English Literature, I'm passionate about helping students improve their language skills. I focus on both written and spoken English.",
    phoneNumber: "+880 1987654321",
    dateOfBirth: "1995-08-20",
    gender: "Female",
    educationLevel: "bachelors",
    institution: "University of Chittagong",
    subjects: ["English", "Literature"],
    division: "Chittagong",
    district: "Chittagong",
    area: "GEC Circle",
    availableDays: ["Tuesday", "Thursday", "Saturday"],
    availableTimes: "2:00 PM - 6:00 PM",
    preferredTeachingMethod: "Online",
  },
  {
    id: 3,
    name: "Bob Johnson",
    subject: "Physics",
    occupation: "Ex-Student",
    experience: 2,
    education: "HSC",
    address: "789 University Road, Shahbag, Dhaka 1000, Bangladesh",
    salary: 6000,
    imageUrl: "/placeholder.svg",
    briefIntroduction:
      "As a recent HSC graduate with a strong background in physics, I'm excited to help students understand the fundamentals of this fascinating subject.",
    phoneNumber: "+880 1765432109",
    dateOfBirth: "2000-11-10",
    gender: "Male",
    educationLevel: "hsc",
    institution: "Dhaka College",
    subjects: ["Physics", "Mathematics"],
    division: "Dhaka",
    district: "Dhaka",
    area: "Shahbag",
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    availableTimes: "5:00 PM - 9:00 PM",
    preferredTeachingMethod: "Both In-person and Online",
  },
]

// Add more mock tutors to demonstrate pagination
for (let i = 4; i <= 50; i++) {
  mockTutors.push({
    id: i,
    name: `Tutor ${i}`,
    subject: "General Studies",
    occupation: "Teacher",
    experience: Math.floor(Math.random() * 10) + 1,
    education: "Bachelor's Degree",
    address: `Address ${i}, Bangladesh`,
    salary: 5000 + Math.floor(Math.random() * 5000),
    imageUrl: "/placeholder.svg",
    briefIntroduction: `I'm Tutor ${i}, and I'm here to help you succeed in your studies.`,
    phoneNumber: "+880 1234567890",
    dateOfBirth: "1990-01-01",
    gender: i % 2 === 0 ? "Male" : "Female",
    educationLevel: "bachelors",
    institution: "University of Bangladesh",
    subjects: ["General Studies"],
    division: "Dhaka",
    district: "Dhaka",
    area: "Area " + i,
    availableDays: ["Monday", "Wednesday", "Friday"],
    availableTimes: "3:00 PM - 7:00 PM",
    preferredTeachingMethod: "Both In-person and Online",
  })
}

const TUTORS_PER_PAGE = 10

export default function SearchPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false)
  const [filters, setFilters] = useState<FilterOptions>({
    occupation: "any",
    minExperience: 0,
    gender: "any",
    educationLevel: "any",
    minSalary: 0,
    maxSalary: 50000,
  })
  const [area, setArea] = useState("")
  const [subject, setSubject] = useState("")
  const { toast } = useToast()

  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    setArea(searchParams.get("area") || "")
    setSubject(searchParams.get("subject") || "")
    setCurrentPage(Number(searchParams.get("page")) || 1)
  }, [searchParams])

  const filterTutors = useCallback(() => {
    return mockTutors.filter((tutor) => {
      const matchesSearch =
        (!area || tutor.address.toLowerCase().includes(area.toLowerCase())) &&
        (!subject || tutor.subject.toLowerCase() === subject.toLowerCase())

      if (!matchesSearch) return false

      return (
        (filters.occupation === "any" || tutor.occupation.toLowerCase() === filters.occupation.toLowerCase()) &&
        tutor.experience >= filters.minExperience &&
        (filters.gender === "any" || tutor.gender.toLowerCase() === filters.gender.toLowerCase()) &&
        (filters.educationLevel === "any" || tutor.educationLevel === filters.educationLevel) &&
        tutor.salary >= filters.minSalary &&
        tutor.salary <= filters.maxSalary
      )
    })
  }, [area, subject, filters])

  const handleApplyFilters = (newFilters: FilterOptions) => {
    setFilters(newFilters)
    setIsFilterModalOpen(false)
    setCurrentPage(1)
    updateSearchParams(1)
  }

  const handleAddToList = (tutorId: number) => {
    toast({
      title: "Sign in required",
      description: "Please sign in to add tutors to your list.",
      duration: 3000,
    })
  }

  const updateSearchParams = (page: number) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set("page", page.toString())
    router.push(`/search?${params.toString()}`)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    updateSearchParams(page)
  }

  const filteredTutors = filterTutors()
  const paginatedTutors = filteredTutors.slice((currentPage - 1) * TUTORS_PER_PAGE, currentPage * TUTORS_PER_PAGE)

  useEffect(() => {
    setTotalPages(Math.ceil(filteredTutors.length / TUTORS_PER_PAGE))
  }, [filteredTutors])

  const isUserSignedIn = false // This should be replaced with actual authentication state

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Search Results</h1>
        <Button variant="outline" size="sm" onClick={() => setIsFilterModalOpen(true)}>
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>

      <p className="text-gray-600 mb-6">
        Showing results for tutors in {area || "all areas"}
        {subject ? ` teaching ${subject}` : ""}
      </p>

      <div className="space-y-6 mb-8">
        {paginatedTutors.map((tutor) => (
          <TutorCard key={tutor.id} {...tutor} onAddToList={handleAddToList} isUserSignedIn={isUserSignedIn} />
        ))}
      </div>

      {/* Pagination */}
      <div className="flex justify-between items-center mt-8">
        <Button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} variant="outline">
          Previous
        </Button>
        <div className="flex items-center space-x-2">
          <span>Page</span>
          <Input
            type="number"
            min={1}
            max={totalPages}
            value={currentPage}
            onChange={(e) => {
              const page = Number.parseInt(e.target.value)
              if (page >= 1 && page <= totalPages) {
                handlePageChange(page)
              }
            }}
            className="w-16 text-center"
          />
          <span>of {totalPages}</span>
        </div>
        <Button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          variant="outline"
        >
          Next
        </Button>
      </div>

      <div className="mt-6">
        <Link href="/" className="text-blue-600 hover:text-blue-800">
          Back to Search
        </Link>
      </div>

      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        onApplyFilters={handleApplyFilters}
      />
    </div>
  )
}

