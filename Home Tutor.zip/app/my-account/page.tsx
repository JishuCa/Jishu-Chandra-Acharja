"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import Image from "next/image"
import { locationData, type Division, type District, type Area } from "@/lib/location-data"

// Updated subject list
const subjects = [
  "Mathematics",
  "English",
  "Physics",
  "Chemistry",
  "Biology",
  "Bangla",
  "ICT",
  "Accounting",
  "History",
  "Geography",
  "Economics",
  "Business Studies",
  "Statistics",
  "Political Science",
  "Sociology",
  "Psychology",
  "Islamic Studies",
  "Computer Science",
  "Art",
  "Music",
]

// Mock user data - in a real application, this would come from a database or API
const mockUserData = {
  name: "John Doe",
  email: "john.doe@example.com",
  phoneNumber: "+880 1234567890",
  dateOfBirth: "1990-05-15",
  gender: "Male",
  occupation: "Teacher",
  educationLevel: "masters",
  institution: "University of Dhaka",
  subjects: ["Mathematics", "Physics"],
  teachingExperience: 5,
  division: "Dhaka",
  district: "Dhaka",
  area: "Uttara",
  address: "123 Main St, Uttara, Dhaka",
  availableDays: ["Monday", "Wednesday", "Friday"],
  availableTimes: "4:00 PM - 8:00 PM",
  preferredTeachingMethod: "In-person",
  expectedSalary: 10000,
  briefIntroduction:
    "I'm a passionate math teacher with 5 years of experience. I specialize in making complex mathematical concepts easy to understand for students of all levels.",
  profilePhoto: "/placeholder.svg",
}

export default function MyAccount() {
  const [userData, setUserData] = useState(mockUserData)
  const [isEditing, setIsEditing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [selectedDivision, setSelectedDivision] = useState<Division | null>(null)
  const [selectedDistrict, setSelectedDistrict] = useState<District | null>(null)
  const [selectedArea, setSelectedArea] = useState<Area | null>(null)

  const divisions = Object.keys(locationData) as Division[]
  const districts = selectedDivision ? (Object.keys(locationData[selectedDivision].districts) as District[]) : []
  const areas = selectedDistrict && selectedDivision ? locationData[selectedDivision].districts[selectedDistrict] : []

  useEffect(() => {
    if (userData.division) {
      setSelectedDivision(userData.division as Division)
    }
  }, [userData.division])

  useEffect(() => {
    if (userData.district) {
      setSelectedDistrict(userData.district as District)
    }
  }, [userData.district])

  useEffect(() => {
    if (userData.area) {
      setSelectedArea(userData.area as Area)
    }
  }, [userData.area])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setUserData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setUserData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, value: string) => {
    setUserData((prev) => ({
      ...prev,
      [name]: prev[name].includes(value) ? prev[name].filter((item: string) => item !== value) : [...prev[name], value],
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, you would send the updated data to your backend here
    console.log("Updated user data:", userData)
    setIsEditing(false)
  }

  const handleProfilePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setUserData((prev) => ({ ...prev, profilePhoto: reader.result as string }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleDivisionChange = (value: string) => {
    setSelectedDivision(value as Division)
    setSelectedDistrict(null)
    setSelectedArea(null)
    setUserData((prev) => ({ ...prev, division: value, district: "", area: "" }))
  }

  const handleDistrictChange = (value: string) => {
    setSelectedDistrict(value as District)
    setSelectedArea(null)
    setUserData((prev) => ({ ...prev, district: value, area: "" }))
  }

  const handleAreaChange = (value: string) => {
    setSelectedArea(value as Area)
    setUserData((prev) => ({ ...prev, area: value }))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Account</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Profile Photo Card */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Photo</CardTitle>
            <CardDescription>Update your profile picture</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="relative w-32 h-32 mb-4">
              <Image
                src={userData.profilePhoto || "/placeholder.svg"}
                alt="Profile"
                layout="fill"
                objectFit="cover"
                className="rounded-full"
              />
            </div>
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleProfilePhotoChange}
              className="hidden"
            />
            <Button type="button" onClick={() => fileInputRef.current?.click()} disabled={!isEditing}>
              Change Photo
            </Button>
          </CardContent>
        </Card>

        {/* Personal Information Card */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Manage your personal details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" name="name" value={userData.name} onChange={handleInputChange} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={userData.email}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input
                  id="phoneNumber"
                  name="phoneNumber"
                  value={userData.phoneNumber}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input
                  id="dateOfBirth"
                  name="dateOfBirth"
                  type="date"
                  value={userData.dateOfBirth}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select
                  name="gender"
                  value={userData.gender}
                  onValueChange={handleSelectChange("gender")}
                  disabled={!isEditing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Professional Information Card */}
        <Card>
          <CardHeader>
            <CardTitle>Professional Information</CardTitle>
            <CardDescription>Update your teaching profile</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="occupation">Occupation</Label>
                <Select
                  name="occupation"
                  value={userData.occupation}
                  onValueChange={handleSelectChange("occupation")}
                  disabled={!isEditing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Occupation" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="ex-student">Ex-Student</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="educationLevel">Education Level</Label>
                <Select
                  name="educationLevel"
                  value={userData.educationLevel}
                  onValueChange={handleSelectChange("educationLevel")}
                  disabled={!isEditing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Education Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ssc">SSC</SelectItem>
                    <SelectItem value="hsc">HSC</SelectItem>
                    <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                    <SelectItem value="masters">Master's Degree</SelectItem>
                    <SelectItem value="phd">PhD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="institution">Institution</Label>
                <Input
                  id="institution"
                  name="institution"
                  value={userData.institution}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="teachingExperience">Teaching Experience (years)</Label>
                <Input
                  id="teachingExperience"
                  name="teachingExperience"
                  type="number"
                  value={userData.teachingExperience}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Subjects</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                {subjects.map((subject) => (
                  <div key={subject} className="flex items-center space-x-2">
                    <Checkbox
                      id={`subject-${subject}`}
                      checked={userData.subjects.includes(subject)}
                      onCheckedChange={() => handleCheckboxChange("subjects", subject)}
                      disabled={!isEditing}
                    />
                    <label htmlFor={`subject-${subject}`}>{subject}</label>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Location and Availability Card */}
        <Card>
          <CardHeader>
            <CardTitle>Location and Availability</CardTitle>
            <CardDescription>Set your teaching location and schedule</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="division">Division</Label>
                <Select
                  name="division"
                  value={selectedDivision || ""}
                  onValueChange={handleDivisionChange}
                  disabled={!isEditing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Division" />
                  </SelectTrigger>
                  <SelectContent>
                    {divisions.map((division) => (
                      <SelectItem key={division} value={division}>
                        {division}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="district">District</Label>
                <Select
                  name="district"
                  value={selectedDistrict || ""}
                  onValueChange={handleDistrictChange}
                  disabled={!isEditing || !selectedDivision}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select District" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts.map((district) => (
                      <SelectItem key={district} value={district}>
                        {district}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="area">Area</Label>
                <Select
                  name="area"
                  value={selectedArea || ""}
                  onValueChange={handleAreaChange}
                  disabled={!isEditing || !selectedDistrict}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Area" />
                  </SelectTrigger>
                  <SelectContent>
                    {areas.map((area) => (
                      <SelectItem key={area} value={area}>
                        {area}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  name="address"
                  value={userData.address}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Available Days</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                  <div key={day} className="flex items-center space-x-2">
                    <Checkbox
                      id={`day-${day}`}
                      checked={userData.availableDays.includes(day)}
                      onCheckedChange={() => handleCheckboxChange("availableDays", day)}
                      disabled={!isEditing}
                    />
                    <label htmlFor={`day-${day}`}>{day}</label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="availableTimes">Available Times</Label>
              <Input
                id="availableTimes"
                name="availableTimes"
                value={userData.availableTimes}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="preferredTeachingMethod">Preferred Teaching Method</Label>
              <Select
                name="preferredTeachingMethod"
                value={userData.preferredTeachingMethod}
                onValueChange={handleSelectChange("preferredTeachingMethod")}
                disabled={!isEditing}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select teaching method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="In-person">In-person</SelectItem>
                  <SelectItem value="Online">Online</SelectItem>
                  <SelectItem value="Both">Both</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Additional Information Card */}
        <Card>
          <CardHeader>
            <CardTitle>Additional Information</CardTitle>
            <CardDescription>Provide more details about your teaching</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="expectedSalary">Expected Salary (BDT/month)</Label>
              <Input
                id="expectedSalary"
                name="expectedSalary"
                type="number"
                value={userData.expectedSalary}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="briefIntroduction">Brief Introduction</Label>
              <Textarea
                id="briefIntroduction"
                name="briefIntroduction"
                value={userData.briefIntroduction}
                onChange={handleInputChange}
                disabled={!isEditing}
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end space-x-2">
          {isEditing ? (
            <>
              <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
              <Button type="submit">Save Changes</Button>
            </>
          ) : (
            <Button type="button" onClick={() => setIsEditing(true)}>
              Edit Information
            </Button>
          )}
        </div>
      </form>
    </div>
  )
}

